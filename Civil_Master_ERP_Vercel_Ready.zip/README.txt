CIVIL MASTER ERP - Vercel Ready

Files:
1. index.html  - Final Employee Management Portal with Leave Management link
2. leave.html  - Leave Management module with Employee Management return link

Upload/deploy the whole folder as one Vercel project.
Open index.html as the main ERP page.

Note: This is front-end navigation. Real shared PostgreSQL data/login across modules requires backend/API integration.
